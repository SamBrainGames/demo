from googleapiclient.discovery import build
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import time

api_key = 'AIzaSyDEq37cX70bmPthM38uYKByGnxKKQtT3dQ'


youtube = build('youtube', 'v3', developerKey=api_key)

scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('./client_secret.json', scope)
client = gspread.authorize(creds)


def makeViewRequest(VidID, sheet):
    request = youtube.videos().list(
            part='statistics',
            id=VidID
        )
    response = request.execute()    
    print(response)
    retrieveSheet(response, sheet, VidID)

def retrieveSheet(response, sheet, VidID):
    if len(response["items"]) != 0:
        views = response["items"][0]["statistics"]["viewCount"]
        print("Views: ", views)
        addInfoToSheet(sheet, VidID, views)
        
    else:
        print("This ID is not valid")

def addInfoToSheet(sheet, VidID, views):
    list_of_values = sheet.get_all_values()
    # print(sheet.cell(5,4))
    # quit()
    original_ID_Loc = list_of_values[0].index(VidID)
    locationCol = list_of_values[1][original_ID_Loc]  
    totalPastViews = 0
    locationRow, totalPastViews = findFirstOpenCell(sheet, locationCol)
    totalViews = int(views) - totalPastViews
    sheet.update_cell(locationRow, locationCol, totalViews)
    print(locationCol)

def findFirstOpenCell(sheet, locationCol):
    openCell = False
    locRow = 6
    totalPastViews = 0
    while openCell == False:
        cell = sheet.cell(locRow, locationCol).value
        print("Cell =", cell)
        if cell == None:
            return locRow, totalPastViews
        else:
            totalPastViews += int(cell)
            locRow += 1


def main():
    keepRunning = True
    sheet = client.open("Youtube Campaign").sheet1
    
    while keepRunning == True:
        ids = getIDS(sheet)
        for vID in ids:
            makeViewRequest(vID, sheet)
        time.sleep(86400) #        

def getIDS(sheet):
    ids = []
    list_of_values = sheet.get_all_values()
    i = 0
    for el in list_of_values[0]:
        if el != '' and i != 0:
            print(el)
            ids.append(el)
        i += 1
    print("Ids: ", ids)
    return ids

if __name__ == "__main__":
    main()




